#include "Cliente.h"

Cliente::Cliente(const std::string& nome, const std::string& cpf, const Endereco& endereco, const Data& nascimento)
    : nome(nome), cpf(cpf), endereco(endereco), nascimento(nascimento) {}

std::string Cliente::getNome() const {
    return nome;
}

void Cliente::setNome(const std::string& nome) {
    this->nome = nome;
}

std::string Cliente::getCpf() const {
    return cpf;
}

void Cliente::setCpf(const std::string& cpf) {
    this->cpf = cpf;
}

Endereco Cliente::getEndereco() const {
    return endereco;
}

void Cliente::setEndereco(const Endereco& endereco) {
    this->endereco = endereco;
}

Data Cliente::getNascimento() const {
    return nascimento;
}

void Cliente::setNascimento(const Data& nascimento) {
    this->nascimento = nascimento;
}
