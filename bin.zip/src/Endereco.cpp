#include "Endereco.h"

Endereco::Endereco(const string& rua, const string& cidade, const string& estado, int numero)
    : rua(rua), cidade(cidade), estado(estado), numero(numero) {}

string Endereco::getRua() const {
    return rua;
}
void Endereco::setRua(const string& rua) {
    this->rua = rua;
}
string Endereco::getCidade() const {
    return cidade;
}
void Endereco::setCidade(const string& cidade) {
    this->cidade = cidade;
}
string Endereco::getEstado() const {
    return estado;
}
void Endereco::setEstado(const string& estado) {
    this->estado = estado;
}
int Endereco::getNumero() const {
    return numero;
}
void Endereco::setNumero(int numero) {
    this->numero = numero;
}
