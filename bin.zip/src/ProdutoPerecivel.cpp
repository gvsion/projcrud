#include "ProdutoPerecivel.h"

ProdutoPerecivel::ProdutoPerecivel(const string& nome, float preco, int quantidade, const string& dataValidade)
    : Produto(nome, preco, quantidade), dataValidade(dataValidade) {}

string ProdutoPerecivel::getDataValidade() const {
    return dataValidade;
}

void ProdutoPerecivel::setDataValidade(const string& dataValidade) {
    this->dataValidade = dataValidade;
}
