#include "Venda.h"
#include <iomanip>

Venda::Venda(const Cliente& cliente, const Produto& produto, int quantidade)
    : cliente(cliente), produto(produto), quantidade(quantidade), total(produto.getPreco() * quantidade) {}

Cliente Venda::getCliente() const {
    return cliente;
}
Produto Venda::getProduto() const {
    return produto;
}
int Venda::getQuantidade() const {
    return quantidade;
}
float Venda::getTotal() const {
    return total;
}
void Venda::exibirVenda() const {
    cout << "Cliente: " << cliente.getNome() << "\n";
    cout << "Produto: " << produto.getNome() << "\n";
    cout << "Quantidade: " << quantidade << "\n";
    cout << "Total: R$ " << fixed << setprecision(2) << total << "\n";
}
