#ifndef ENDERECO_H
#define ENDERECO_H

#include <string>
using namespace std;
class Endereco {
private:
    string rua;
    string cidade;
    string estado;
    int numero;
public:
    Endereco(const string& rua, const string& cidade, const string& estado, int numero);

    string getRua() const;
    void setRua(const string& rua);

    string getCidade() const;
    void setCidade(const string& cidade);

    string getEstado() const;
    void setEstado(const string& estado);

    int getNumero() const;
    void setNumero(int numero);
};

#endif
