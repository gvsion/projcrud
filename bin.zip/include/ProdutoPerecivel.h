#ifndef PRODUTO_PERECIVEL_H
#define PRODUTO_PERECIVEL_H

#include "Produto.h"

class ProdutoPerecivel : public Produto {
private:
    string dataValidade;

public:
    ProdutoPerecivel(const string& nome, float preco, int quantidade, const string& dataValidade);

    string getDataValidade() const;
    void setDataValidade(const string& dataValidade);
};

#endif
