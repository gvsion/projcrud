#ifndef VENDA_H
#define VENDA_H

#include "Cliente.h"
#include "Produto.h"

class Venda {
public:
    Venda(const Cliente& cliente, const Produto& produto, int quantidade);
    Cliente getCliente() const;
    Produto getProduto() const;
    int getQuantidade() const;
    float getTotal() const;
    void exibirVenda() const;

private:
    Cliente cliente;
    Produto produto;
    int quantidade;
};

#endif
