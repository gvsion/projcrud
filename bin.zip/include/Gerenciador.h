#ifndef GERENCIADOR_H
#define GERENCIADOR_H

#include <vector>
#include "Cliente.h"
#include "Produto.h"
#include "ProdutoPerecivel.h"

class Gerenciador {
private:
    vector<Cliente> clientes;
    vector<Produto*> produtos;
    size_t pesquisarCliente(const string& nome) const;
    size_t pesquisarProduto(const string& nome) const;

public:
    ~Gerenciador();

    void inserirCliente(const Cliente& cliente);
    void listarClientes() const;
    void exibirCliente(const string& nome) const;
    void alterarCliente(const string& nome);
    void removerCliente(const string& nome);

    void inserirProduto(Produto* produto);
    void listarProdutos() const;
    void exibirProduto(const string& nome) const;
    void alterarProduto(const std::string& nome);
    void removerProduto(const std::string& nome);

    void realizarVenda();
    void gerarRelatorio() const;
    void carregarDados();
    void salvarDados() const;
    void menu();
};

#endif
