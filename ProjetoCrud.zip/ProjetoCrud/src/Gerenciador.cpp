#include "Gerenciador.h"
#include <iostream>
#include <fstream>
#include <cstdlib>
using namespace std;

Gerenciador::~Gerenciador() {
    for (auto produto : produtos) {
        delete produto;
    }
}

void limparTela() {
    #ifdef _WIN32
        system("cls");
    #else
        system("clear");
    #endif
}

size_t Gerenciador::pesquisarCliente(const string& nome) const {
    for (size_t i = 0; i < clientes.size(); ++i) {
        if (clientes[i].getNome() == nome) {
            return i;
        }
    }
    return clientes.size();
}

size_t Gerenciador::pesquisarProduto(const string& nome) const {
    for (size_t i = 0; i < produtos.size(); ++i) {
        if (produtos[i]->getNome() == nome) {
            return i;
        }
    }
    return produtos.size();
}

void Gerenciador::inserirCliente(const Cliente& cliente) {
    clientes.push_back(cliente);
    cout << "Cliente inserido com sucesso!\n";
}

void Gerenciador::listarClientes() const {
    if (clientes.empty()) {
        cout << "Nenhum cliente cadastrado.\n";
        return;
    }

    cout << "Lista de Clientes:\n";
    for (const auto& cliente : clientes) {
        cout << "Nome: " << cliente.getNome() << ", CPF: " << cliente.getCpf() << "\n";
    }
}

void Gerenciador::exibirCliente(const string& nome) const {
    size_t indice = pesquisarCliente(nome);
    if (indice != clientes.size()) {
        const Cliente& cliente = clientes[indice];
        cout << "Nome: " << cliente.getNome() << "\n";
        cout << "CPF: " << cliente.getCpf() << "\n";
        cout << "Endereco: " << cliente.getEndereco().getRua() << ", "
             << cliente.getEndereco().getNumero() << ", "
             << cliente.getEndereco().getCidade() << ", "
             << cliente.getEndereco().getEstado() << "\n";
        cout << "Data de Nascimento: "
             << cliente.getNascimento().getDia() << "/"
             << cliente.getNascimento().getMes() << "/"
             << cliente.getNascimento().getAno() << "\n";
    } else {
        cout << "Cliente nao encontrado.\n";
    }
}

void Gerenciador::alterarCliente(const std::string& nome) {
    size_t indice = pesquisarCliente(nome);
    if (indice != clientes.size()) {
        string novoNome, novoCpf, rua, cidade, estado;
        int numero, dia, mes, ano;

        cout << "Novo nome: ";
        cin >> novoNome;
        cout << "Novo CPF: ";
        cin >> novoCpf;
        cout << "Nova Rua: ";
        cin >> rua;
        cout << "Novo N�mero: ";
        cin >> numero;
        cout << "Nova Cidade: ";
        cin >> cidade;
        cout << "Novo Estado: ";
        cin >> estado;
        cout << "Nova Data de Nascimento (dia mes ano): ";
        cin >> dia >> mes >> ano;

        clientes[indice] = Cliente(novoNome, novoCpf, Endereco(rua, cidade, estado, numero), Data(dia, mes, ano));
        cout << "Cliente alterado com sucesso!\n";
    } else {
        cout << "Cliente nao encontrado.\n";
    }
}

void Gerenciador::removerCliente(const std::string& nome) {
    size_t indice = pesquisarCliente(nome);
    if (indice != clientes.size()) {
        clientes.erase(clientes.begin() + indice);
        cout << "Cliente removido com sucesso!\n";
    } else {
        cout << "Cliente n�o encontrado.\n";
    }
}

void Gerenciador::inserirProduto(Produto* produto) {
    produtos.push_back(produto);
    cout << "Produto inserido com sucesso!\n";
}

void Gerenciador::listarProdutos() const {
    if (produtos.empty()) {
        cout << "Nenhum produto cadastrado.\n";
        return;
    }

    cout << "Lista de Produtos:\n";
    for (const auto& produto : produtos) {
        cout << "Nome: " << produto->getNome() << ", Preco: " << produto->getPreco() << ", Quantidade: " << produto->getQuantidade() << "\n";
    }
}

void Gerenciador::exibirProduto(const string& nome) const {
    size_t indice = pesquisarProduto(nome);
    if (indice != produtos.size()) {
        const Produto* produto = produtos[indice];
        cout << "Nome: " << produto->getNome() << "\n";
        cout << "Preco: " << produto->getPreco() << "\n";
        cout << "Quantidade: " << produto->getQuantidade() << "\n";
        if (const ProdutoPerecivel* pp = dynamic_cast<const ProdutoPerecivel*>(produto)) {
            cout << "Data de Validade: " << pp->getDataValidade() << "\n";
        }
    } else {
        cout << "Produto nao encontrado.\n";
    }
}

void Gerenciador::alterarProduto(const std::string& nome) {
    size_t indice = pesquisarProduto(nome);
    if (indice != produtos.size()) {
        string novoNome;
        float novoPreco;
        int novaQuantidade;
        string novaDataValidade;

        cout << "Novo nome: ";
        cin >> novoNome;
        cout << "Novo preco: ";
        cin >> novoPreco;
        cout << "Nova quantidade: ";
        cin >> novaQuantidade;

        delete produtos[indice];

        cout << "produto perec�vel (s/n)? ";
        char tipo;
        cin >> tipo;
        if (tipo == 's') {
            cout << "Nova Data de Validade: ";
            cin >> novaDataValidade;
            produtos[indice] = new ProdutoPerecivel(novoNome, novoPreco, novaQuantidade, novaDataValidade);
        } else {
            produtos[indice] = new Produto(novoNome, novoPreco, novaQuantidade);
        }
        cout << "Produto alterado com sucesso!\n";
    } else {
        cout << "Produto nao encontrado.\n";
    }
}

void Gerenciador::removerProduto(const std::string& nome) {
    size_t indice = pesquisarProduto(nome);
    if (indice != produtos.size()) {
        delete produtos[indice];
        produtos.erase(produtos.begin() + indice);
        cout << "Produto removido com sucesso!\n";
    } else {
        cout << "Produto nao encontrado.\n";
    }
}

void Gerenciador::realizarVenda() {
    listarClientes();
    cout << "Digite o nome do cliente: ";
    string nomeCliente;
    cin.ignore();
    getline(cin, nomeCliente);

    size_t indiceCliente = pesquisarCliente(nomeCliente);
    if (indiceCliente == clientes.size()) {
        cout << "Cliente nao encontrado.\n";
        return;
    }

    listarProdutos();
    cout << "Digite o nome do produto: ";
    string nomeProduto;
    getline(cin, nomeProduto);

    size_t indiceProduto = pesquisarProduto(nomeProduto);
    if (indiceProduto == produtos.size()) {
        cout << "Produto n�o encontrado.\n";
        return;
    }

    Produto* produto = produtos[indiceProduto];
    int quantidadeVenda;
    cout << "Digite a quantidade a ser vendida: ";
    cin >> quantidadeVenda;

    if (quantidadeVenda > produto->getQuantidade()) {
        cout << "Quantidade dispon�vel insuficiente.\n";
        return;
    }

    produto->setQuantidade(produto->getQuantidade() - quantidadeVenda);
    cout << "Venda realizada com sucesso!\n";
}
void Gerenciador::gerarRelatorio() const {
    ofstream arquivo("relatorio.txt");
    if (!arquivo.is_open()) {
        cout << "erro.\n";
        return;
    }

    arquivo << "Relat�rio de Clientes e Produtos\n";
    arquivo << "================================\n\n";

    arquivo << "Clientes:\n";
    if (clientes.empty()) {
        arquivo << "Nenhum cliente cadastrado.\n";
    } else {
        for (const auto& cliente : clientes) {
            arquivo << "Nome: " << cliente.getNome() << "\n";
            arquivo << "CPF: " << cliente.getCpf() << "\n";
            arquivo << "Endereco: " << cliente.getEndereco().getRua() << ", "
                   << cliente.getEndereco().getNumero() << ", "
                   << cliente.getEndereco().getCidade() << ", "
                   << cliente.getEndereco().getEstado() << "\n";
            arquivo << "Data de Nascimento: "
                   << cliente.getNascimento().getDia() << "/"
                   << cliente.getNascimento().getMes() << "/"
                   << cliente.getNascimento().getAno() << "\n";
            arquivo << "--------------------------------\n";
        }
    }
    arquivo << "\n";

    arquivo << "Produtos:\n";
    if (produtos.empty()) {
        arquivo << "Nenhum produto cadastrado.\n";
    } else {
        for (const auto& produto : produtos) {
            arquivo << "Nome: " << produto->getNome() << "\n";
            arquivo << "Preco: " << produto->getPreco() << "\n";
            arquivo << "Quantidade: " << produto->getQuantidade() << "\n";
            if (const ProdutoPerecivel* pp = dynamic_cast<const ProdutoPerecivel*>(produto)) {
                arquivo << "Data de Validade: " << pp->getDataValidade() << "\n";
            }
            arquivo << "--------------------------------\n";
        }
    }

    arquivo.close();
    cout << "Relatorio gerado com sucesso!\n";
}
void Gerenciador::carregarDados() {
    ifstream arquivoClientes("clientes.txt");
    ifstream arquivoProdutos("produtos.txt");

    if (!arquivoClientes.is_open() || !arquivoProdutos.is_open()) {
        cout << "Erro \n";
        return;
    }

    clientes.clear();
    for (auto produto : produtos) {
        delete produto;
    }
    produtos.clear();

    string nome, cpf, rua, cidade, estado;
    int numero, dia, mes, ano;

    while (getline(arquivoClientes, nome) && !nome.empty()) {
        getline(arquivoClientes, cpf);
        getline(arquivoClientes, rua);
        arquivoClientes >> numero;
        arquivoClientes.ignore();
        getline(arquivoClientes, cidade);
        getline(arquivoClientes, estado);
        arquivoClientes >> dia >> mes >> ano;
        arquivoClientes.ignore();

        clientes.push_back(Cliente(nome, cpf, Endereco(rua, cidade, estado, numero), Data(dia, mes, ano)));
    }

    string nomeProduto;
    float preco;
    int quantidade;
    string tipoProduto, dataValidade;

    while (getline(arquivoProdutos, nomeProduto) && !nomeProduto.empty()) {
        arquivoProdutos >> preco >> quantidade;
        arquivoProdutos.ignore();
        getline(arquivoProdutos, tipoProduto);

        if (tipoProduto == "perecivel") {
            getline(arquivoProdutos, dataValidade);
            produtos.push_back(new ProdutoPerecivel(nomeProduto, preco, quantidade, dataValidade));
        } else {
            produtos.push_back(new Produto(nomeProduto, preco, quantidade));
        }
    }

    arquivoClientes.close();
    arquivoProdutos.close();
}
void Gerenciador::salvarDados() const {
    ofstream arquivoClientes("clientes.txt");
    ofstream arquivoProdutos("produtos.txt");

    if (!arquivoClientes.is_open() || !arquivoProdutos.is_open()) {
        cout << "Erro ao abrir arquivos para salvar dados.\n";
        return;
    }

    for (const auto& cliente : clientes) {
        arquivoClientes << cliente.getNome() << "\n"
                        << cliente.getCpf() << "\n"
                        << cliente.getEndereco().getRua() << "\n"
                        << cliente.getEndereco().getNumero() << "\n"
                        << cliente.getEndereco().getCidade() << "\n"
                        << cliente.getEndereco().getEstado() << "\n"
                        << cliente.getNascimento().getDia() << " "
                        << cliente.getNascimento().getMes() << " "
                        << cliente.getNascimento().getAno() << "\n";
    }

    for (const auto& produto : produtos) {
        arquivoProdutos << produto->getNome() << "\n"
                        << produto->getPreco() << "\n"
                        << produto->getQuantidade() << "\n";
        if (const ProdutoPerecivel* pp = dynamic_cast<const ProdutoPerecivel*>(produto)) {
            arquivoProdutos << "perecivel\n" << pp->getDataValidade() << "\n";
        } else {
            arquivoProdutos << "normal\n";
        }
    }

    arquivoClientes.close();
    arquivoProdutos.close();
}


void Gerenciador::menu() {
    int opcao;
    do {
        limparTela();
        cout << "Menu:\n";
        cout << "1. Gerenciar Clientes\n";
        cout << "2. Gerenciar Produtos\n";
        cout << "3. Realizar Venda\n";
        cout << "4. Gerar Relatorio\n";
        cout << "0. Sair\n";
        cout << "Escolha uma opcao: ";
        cin >> opcao;


        switch (opcao) {
            case 1: {
                int subOpcao;
                do {
                    limparTela();
                    cout << "\nMenu Cliente:\n";
                    cout << "1. Inserir Cliente\n";
                    cout << "2. Listar Clientes\n";
                    cout << "3. Exibir Cliente\n";
                    cout << "4. Alterar Cliente\n";
                    cout << "5. Remover Cliente\n";
                    cout << "0. Voltar\n";
                    cout << "Escolha uma opcao: ";
                    cin >> subOpcao;

                    switch (subOpcao) {
                    case 1: {
                            string nome, cpf, rua, cidade, estado;
                            int numero, dia, mes, ano;

                            cout << "Nome: ";
                            cin.ignore();
                            getline(cin, nome);

                            cout << "CPF: ";
                            cin >> cpf;

                            cout << "Rua: ";
                            cin.ignore();
                            getline(cin, rua);

                           cout << "Numero: ";
                           cin >> numero;

                           cout << "Cidade: ";
                           cin.ignore();
                            getline(cin, cidade);
                            cout << "Estado: ";
                            cin >> estado;

                            cout << "Data de Nascimento (dia mes ano): ";
                            cin >> dia >> mes >> ano;

                            inserirCliente(Cliente(nome, cpf, Endereco(rua, cidade, estado, numero), Data(dia, mes, ano)));
                            break;
                        }
                        case 2:
                            listarClientes();
                            break;
                        case 3: {
                            string nome;
                            cout << "Nome do cliente: ";
                            cin >> nome;
                            exibirCliente(nome);
                            break;
                        }
                        case 4: {
                            string nome;
                            cout << "Nome do cliente: ";
                            cin >> nome;
                            alterarCliente(nome);
                            break;
                        }
                        case 5: {
                            string nome;
                            cout << "Nome do cliente: ";
                            cin >> nome;
                            removerCliente(nome);
                            break;
                        }
                        case 0:
                            break;
                        default:
                            cout << "Opcao invalida.\n";
                            break;
                    }
                    if (subOpcao != 0) {
                        cout << "Pressione Enter para continuar...";
                        cin.ignore();
                        cin.get();
                    }
                } while (subOpcao != 0);
                break;
            }
            case 2: {
                int subOpcao;
                do {
                    limparTela();
                    cout << "\nMenu Produto:\n";
                    cout << "1. Inserir Produto\n";
                    cout << "2. Listar Produtos\n";
                    cout << "3. Exibir Produto\n";
                    cout << "4. Alterar Produto\n";
                    cout << "5. Remover Produto\n";
                    cout << "0. Voltar\n";
                    cout << "Escolha uma opcao: ";
                    cin >> subOpcao;

                    switch (subOpcao) {
                        case 1: {
                            string nome;
                            float preco;
                            int quantidade;
                            string tipoProduto, dataValidade;
                            cout << "Nome: ";
                            cin.ignore();
                            getline(cin, nome);
                            cout << "Preco: ";
                            cin >> preco;
                            cout << "Quantidade: ";
                            cin >> quantidade;

                            cout << "Tipo (normal/perecivel): ";
                            cin >> tipoProduto;

                            if (tipoProduto == "perecivel") {
                                cout << "Data de Validade: ";
                                cin >> dataValidade;
                                inserirProduto(new ProdutoPerecivel(nome, preco, quantidade, dataValidade));
                            } else {
                                inserirProduto(new Produto(nome, preco, quantidade));
                            }
                            break;
                        }
                        case 2:
                            listarProdutos();
                            break;
                        case 3: {
                            string nome;
                            cout << "Nome do produto: ";
                            cin >> nome;
                            exibirProduto(nome);
                            break;
                        }
                        case 4: {
                            string nome;
                            cout << "Nome do produto: ";
                            cin >> nome;
                            alterarProduto(nome);
                            break;
                        }
                        case 5: {
                            string nome;
                            cout << "Nome do produto: ";
                            cin >> nome;
                            removerProduto(nome);
                            break;
                        }
                        case 0:
                            break;
                        default:
                            cout << "Opcao invalida.\n";
                            break;
                    }
                    if (subOpcao != 0) {
                        cout << "Pressione Enter para continuar...";
                        cin.ignore();
                        cin.get();
                    }
                } while (subOpcao != 0);
                break;
            }
            case 3:
                limparTela();
                realizarVenda();
                break;
            case 4:
                limparTela();
                gerarRelatorio();
                break;
            case 0:
                salvarDados();
                limparTela();
                cout << "Saindo...\n";
                break;
            default:
                cout << "Opc�o invalida.\n";
                break;
        }
        if (opcao != 0) {
            cout << "Pressione Enter para continuar...";
            cin.ignore();
            cin.get();
        }
    } while (opcao != 0);
}
