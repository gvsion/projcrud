#include "Produto.h"

Produto::Produto(const string& nome, float preco, int quantidade)
    : nome(nome), preco(preco), quantidade(quantidade) {}

Produto::~Produto() {}

string Produto::getNome() const {
    return nome;
}

void Produto::setNome(const string& nome) {
    this->nome = nome;
}

float Produto::getPreco() const {
    return preco;
}

void Produto::setPreco(float preco) {
    this->preco = preco;
}

int Produto::getQuantidade() const {
    return quantidade;
}

void Produto::setQuantidade(int quantidade) {
    this->quantidade = quantidade;
}
