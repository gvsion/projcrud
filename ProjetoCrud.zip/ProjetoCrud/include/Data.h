#ifndef DATA_H
#define DATA_H

using namespace std;

class Data {
private:
    int dia;
    int mes;
    int ano;
public:
    Data(int dia, int mes, int ano);
    int getDia() const;
    void setDia(int dia);
    int getMes() const;
    void setMes(int mes);
    int getAno() const;
    void setAno(int ano);
};

#endif
