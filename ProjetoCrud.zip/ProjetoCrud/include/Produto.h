#ifndef PRODUTO_H
#define PRODUTO_H

#include <string>
using namespace std;

class Produto {
private:
    string nome;
    float preco;
    int quantidade;

public:
    Produto(const string& nome, float preco, int quantidade);

    virtual ~Produto();

    string getNome() const;
    void setNome(const string& nome);

    float getPreco() const;
    void setPreco(float preco);

    int getQuantidade() const;
    void setQuantidade(int quantidade);
};

#endif
