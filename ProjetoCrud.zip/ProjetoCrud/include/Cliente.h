#ifndef CLIENTE_H
#define CLIENTE_H
#include <string>
#include "Endereco.h"
#include "Data.h"
using namespace std;
class Cliente {
private:
    string nome;
    string cpf;
    Endereco endereco;
    Data nascimento;

public:
    Cliente(const string& nome, const string& cpf, const Endereco& endereco, const Data& nascimento);

    string getNome() const;
    void setNome(const string& nome);

    string getCpf() const;
    void setCpf(const string& cpf);

    Endereco getEndereco() const;
    void setEndereco(const Endereco& endereco);

    Data getNascimento() const;
    void setNascimento(const Data& nascimento);
};

#endif
